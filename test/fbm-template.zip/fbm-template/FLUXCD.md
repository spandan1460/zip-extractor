
# FluxCD.io

https://fluxcd.io

# Installation

## OS/X

```bash
brew update
brew install flux
```

# Youtube Documentation

* https://www.youtube.com/watch?v=PFLimPh5-wo
* 
