import { Router } from 'express'; 
import {globalSearch} from '../middleware/globalSearch.js'

const sfdcRouter = Router();

sfdcRouter.get('/globalsearch', globalSearch)

export {sfdcRouter}