import jsForce from 'jsforce';
import jwtToken from ('salesforce-jwt-bearer-token-flow')
// const jsForce = require('jsforce');
// const jwt = require("salesforce-jwt-bearer-token-flow");
const sfdcConn = new jsForce.Connection();
global.accessToken = '00D0D000000D7aM!AQ8AQDf8IHg3UOyjZTbou8WLwyIf9axnIEM30oYNtxq7ShbUdPqL5eTjiEinAPWxMz2qw1zF5cWLXHZu7zCCrl5aYOSt0Wpc';
global.instanceUrl = 'https://maersk--preprod01.my.salesforce.com';

//For Testing
var sf = require('node-salesforce');
var conn = new sf.Connection({
    oauth2 :  {
        loginUrl: 'https://test.salesforce.com',
        clientId: '3MVG9qQjGkWUbcrFTIsUBxAfZQqzaI1ARwQ6XVIC5cOxtcN7ENBv3Rq5jxemgaHRWuDpfuBEjA028VC0DAhT6',
        clientSecret: '35D35503555CF1F99EA47333E91E87772568E5FAED20206BBFA73CC7FACFCEDB'
    }
});
let username = 'ayush.k@maersk.com.preprod01'
let password = 'Ayush@123rXyRy2pQJUdQUDPRgsk8VoPA9'
conn.login(username, password, function(err, userInfo) {
  if (err) { return console.error(err); }
  accessToken = conn.accessToken;
  instanceUrl = conn.instanceUrl;
});

// jwt.getToken({
//     iss: '3MVG9qQjGkWUbcrGSeSz8.WM65tcytWr1t7z8EpKCHvjDooif_idWi9iBw2n_ma1cIoMQ9PJ1X46xUOeQi9B0',
//     sub: 'empinterface@maersk.com.preprod01',
//     aud: 'https://test.salesforce.com/',
//     privateKey: 'PK'
//     }, function(err, token) {
//       console.log("JSForce Connection started");
//       if (err) {
//         return console.error(err);
//       }else{
//         console.log(token.instance_url)
//         accessToken = token.access_token;
//         instanceUrl = token.instance_url;
//       }
//     //   console.log(instanceUrl);
//     //   sfdcConn.initialize({
//     //     instanceUrl: instanceUrl,
//     //     accessToken: accessToken
//     //   });
//     }
// )

module.exports = {sfdcConn}