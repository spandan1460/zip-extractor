import { sfdcRestGetCallout } from "../utils/sfdcRestGetCallout.js"

//Global Search From Salesforce Search API.
const globalSearch = (req,res) =>{
    
    const text = req.query.text
    const objects = req.query.objects
    const maxresult = req.query.maxresult
    
    //text.replace('?','\?').replace('&','\&').replaceAll('|','\|').replaceAll('!','\!').replaceAll('{','\{').replaceAll('}','\}').replaceAll('[','\[').replaceAll(']','\]').replaceAll('(','\(').replaceAll(')','\)').replaceAll('^','\^').replaceAll('~','\~').replaceAll('*','\*').replaceAll(',','\,').replaceAll('"','\"').replaceAll("'","\'").replaceAll('+','\+').replaceAll('-','\-');

    const searchRestApiUrl ='/services/data/v56.0/search/?q='
    let returnedfields = {
        case : 'CaseNumber,Contact_Name__c,Subject,Priority,CreatedDate,Owner.Name,status',
        account: 'Name,SCV_Code__c,Recordtype.name,Country__c,SCV_Status__c,Value_Proposition__c,Concern_Code__c',
        emailmessage : 'Subject,FromAddress,ToAddress,MessageDate,Status,HasAttachment,Incoming',
        contentversion : 'Description,Document_Type__c,FileType,ContentSize,Title,FileExtension',
        contact : 'Name,Account.Name,Email,Cluster_Name__c,Contact_Type__c,CSAT_Opt_Out__c,Recordtype.name'
    }

    let query = "Find {*"+text+ "*} In All Fields Returning"
    if(objects == '' || objects == undefined || objects == null){
      for(let object of Object.keys(returnedfields)){
        query +=" " + object + "("+returnedfields[object]+"),"
      }
    }else{
      let lstobject = objects.split(',')
      for(let object of lstobject){        
        query += " " + object + "("+returnedfields[object]+"),"
      }
    }
    query = query.slice(0, -1)
    
    if(maxresult == '' || maxresult == undefined || maxresult == null){
      query += ' LIMIT 10';
    }else{
      query += ' LIMIT '+ maxresult;
    }
    
    sfdcRestGetCallout(query,searchRestApiUrl).then(
        response => {
            // caseSearchModel();
            // accountSearchModel();
            // contactSearchModel();
            // emailSearchModel();
            // fileSearchModel();
            let jsonResponse = JSON.parse(response.body)
            let searchRecords = jsonResponse["searchRecords"]
            res.send(searchRecords)
        }
    ).catch(
        error => console.error('Error in Global Search Rest Callout function ' + error + " " + error.stack)
    )
}

export {globalSearch}