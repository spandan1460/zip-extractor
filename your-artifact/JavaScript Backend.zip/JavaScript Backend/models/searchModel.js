const caseSearchModel = () =>{

}

const accountSearchModel = () =>{
    
}
const emailSearchModel = () =>{
    
}
const contactSearchModel = () =>{
    
}
const fileSearchModel = () =>{
    
}

export {caseSearchModel,accountSearchModel,emailSearchModel,contactSearchModel,fileSearchModel}