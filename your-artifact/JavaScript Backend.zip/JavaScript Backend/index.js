import express from 'express';
import compression from 'compression';
import {sfdcRouter} from './routes/search.js'
import cors from 'cors';

var corsOptions = {
    origin: 'http://localhost:3000',
    optionsSuccessStatus: 200 // For legacy browser support
    }
    

global.accessToken = '0D0D000000D7aM!AQ8AQEsDV4MgQmh9gHrkAddGNlzEK1kEQd._r1lMRxqYtumuAUa_l8N9.LWQaJut2wtK0.xXcwIZdquilkzJ3CxaB6AMOsO9';
global.instanceUrl = 'https://maersk--preprod01.my.salesforce.com';

let port = process.env.PORT || 3005;

const app = express();
app.use(compression());

app.get("/", (req, res) => {
    res.send("Api Working!");
});

app.use(cors(corsOptions));

app.use("/sfdcApi",sfdcRouter)

app.listen(port, () => {
    console.log("Artemis app is listening on worker");
});
