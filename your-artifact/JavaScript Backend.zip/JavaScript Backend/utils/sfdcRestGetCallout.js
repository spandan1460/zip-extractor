import request from 'request';

let sfdcRestGetCallout =  (query,restApiUrl) => {
    console.log('SFDC Rest Callout Started')
    let options = {};
    options.url = instanceUrl + restApiUrl + query;
    options.headers = {
      'Authorization': 'Bearer ' + accessToken
    }
    return new Promise((resolve, reject) => {
      request.get(options, async function (error, response, body) {
        if (error) {
          reject(error);
        } else {
          resolve(response)
        }
      })
    })
  }

export {sfdcRestGetCallout}